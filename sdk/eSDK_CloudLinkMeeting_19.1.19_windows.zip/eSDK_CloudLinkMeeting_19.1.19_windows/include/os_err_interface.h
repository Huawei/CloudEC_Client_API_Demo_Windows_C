/**************************************************************************/
/*                                                                        */
/*              Copyright  2005-2009, Huawei Tech. Co., Ltd.              */
/*                      ALL RIGHTS RESERVED                               */
/*                                                                        */
/*                                                                        */
/*  File Name     :  os_err_interface.h                               */
/*                                                                        */
/*  Author         : �Ŷ��� 36904                                            */
/*  Create Date    : 2005-10-21                                          */
/*  Description     : about vtop os errno define                                       */
/*  Others         :                                                      */
/*  Version        : 1.0                                                  */
/*------------------------------------------------------------------------*/
/*  Function List   :                                                     */
/*  Name                Function                                          */
/*                                                                        */
/*------------------------------------------------------------------------*/
/*  History         :                                                     */
/*  Data            Author      Modification                              */
/*                                                                        */
/**************************************************************************/

#include "errno.h"
#include "os_types_interface.h"
#include "os_def.h"


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#ifndef __OS_ERR_INTERFACE_H__
#define __OS_ERR_INTERFACE_H__

/**********************************************************
|                                 �����붨��                                       |
**********************************************************/

#define VTOP_ERR_PTRPARAM_ISNULL (-1)
#define VTOP_ERR_OSCALL_ERROR  (-1)
#define VTOP_ERR_NO_MEMORY     (-1)
#define VTOP_ERR_SYSNO_MATCH   (-2)

#define VTOP_ERR_BUF_LEN        64

#ifdef WIN32
/*lint -save -e452*/
typedef int socklen_t;
/*lint -restore*/

/*lint -save -e547*/
// #define EWOULDBLOCK             WSAEWOULDBLOCK
// #define EINPROGRESS             WSAEINPROGRESS
// #define EALREADY                WSAEALREADY
// #define ENOTSOCK                WSAENOTSOCK
// #define EDESTADDRREQ            WSAEDESTADDRREQ
// #define EMSGSIZE                WSAEMSGSIZE
// #define EPROTOTYPE              WSAEPROTOTYPE
// #define ENOPROTOOPT             WSAENOPROTOOPT
// #define EPROTONOSUPPORT         WSAEPROTONOSUPPORT
// #define ESOCKTNOSUPPORT         WSAESOCKTNOSUPPORT
// #define EOPNOTSUPP              WSAEOPNOTSUPP
// #define EPFNOSUPPORT            WSAEPFNOSUPPORT
// #define EAFNOSUPPORT            WSAEAFNOSUPPORT
// #define EADDRINUSE              WSAEADDRINUSE
// #define EADDRNOTAVAIL           WSAEADDRNOTAVAIL
// #define ENETDOWN                WSAENETDOWN
// #define ENETUNREACH             WSAENETUNREACH
// #define ENETRESET               WSAENETRESET
// #define ECONNABORTED            WSAECONNABORTED
// #define ECONNRESET              WSAECONNRESET
// #define ENOBUFS                 WSAENOBUFS
// #define EISCONN                 WSAEISCONN
// #define ENOTCONN                WSAENOTCONN
// #define ESHUTDOWN               WSAESHUTDOWN
// #define ETOOMANYREFS            WSAETOOMANYREFS
// #define ETIMEDOUT               WSAETIMEDOUT
// #define ECONNREFUSED            WSAECONNREFUSED
// #define ELOOP                   WSAELOOP
// #define EHOSTDOWN               WSAEHOSTDOWN
// #define EHOSTUNREACH            WSAEHOSTUNREACH
// #define EPROCLIM                WSAEPROCLIM
// #define EUSERS                  WSAEUSERS
// #define EDQUOT                  WSAEDQUOT
// #define ESTALE                  WSAESTALE
// #define EREMOTE                 WSAEREMOTE
/*lint -restore*/
#else


#define WSANOTINITIALISED  EPROTONOSUPPORT

#endif



/** Ϊ����STƽ̨�ϳɹ����룬��ʱ���ϣ�Ӧ����VTOPͳһ�޸� */
#ifndef EINTR
#define EINTR 0x0fffffff
#endif

#define    VTOP_ERR_OS_EPERM         EPERM    /* Operation not permitted */
#define    VTOP_ERR_OS_ENOENT        ENOENT    /* No such file or directory */
#define    VTOP_ERR_OS_ESRCH         ESRCH    /* No such process */

#define VTOP_ERR_OS_EINTR       EINTR  /* Interrupted system call */

#define    VTOP_ERR_OS_EIO           EIO    /* I/O error */
#define    VTOP_ERR_OS_ENXIO         ENXIO    /* No such device or address */
#define    VTOP_ERR_OS_E2BIG         E2BIG    /* Arg list too long */
#define    VTOP_ERR_OS_ENOEXEC     ENOEXEC    /* Exec format error */
#define    VTOP_ERR_OS_EBADF         EBADF    /* Bad file number */
#define    VTOP_ERR_OS_ECHILD        ECHILD    /* No child processes */
#define    VTOP_ERR_OS_EAGAIN        EAGAIN    /* Try again */
#define    VTOP_ERR_OS_ENOMEM        ENOMEM    /* Out of memory */
#define    VTOP_ERR_OS_EACCES        EACCES    /* Permission denied */
#define    VTOP_ERR_OS_EFAULT        EFAULT    /* Bad address */
#define    VTOP_ERR_OS_ENOTBLK        ENOTBLK    /* Block device required */
#define    VTOP_ERR_OS_EBUSY        EBUSY    /* Device or resource busy */
#define    VTOP_ERR_OS_EEXIST        EEXIST    /* File exists */
#define    VTOP_ERR_OS_EXDEV        EXDEV    /* Cross-device link */
#define    VTOP_ERR_OS_ENODEV        ENODEV    /* No such device */
#define    VTOP_ERR_OS_ENOTDIR        ENOTDIR    /* Not a directory */
#define    VTOP_ERR_OS_EISDIR        EISDIR    /* Is a directory */
#define    VTOP_ERR_OS_EINVAL        EINVAL    /* Invalid argument */
#define    VTOP_ERR_OS_ENFILE        ENFILE    /* File table overflow */
#define    VTOP_ERR_OS_EMFILE        EMFILE    /* Too many open files */
#define    VTOP_ERR_OS_ENOTTY        ENOTTY    /* Not a typewriter */
#define    VTOP_ERR_OS_ETXTBSY        ETXTBSY    /* Text file busy */
#define    VTOP_ERR_OS_EFBIG        EFBIG    /* File too large */
#define    VTOP_ERR_OS_ENOSPC        ENOSPC    /* No space left on device */
#define    VTOP_ERR_OS_ESPIPE        ESPIPE    /* Illegal seek */
#define    VTOP_ERR_OS_EROFS        EROFS    /* Read-only file system */
#define    VTOP_ERR_OS_EMLINK        EMLINK    /* Too many links */
#define    VTOP_ERR_OS_EPIPE        EPIPE    /* Broken pipe */
#define    VTOP_ERR_OS_EDOM        EDOM    /* Math argument out of domain of func */
#define    VTOP_ERR_OS_ERANGE        ERANGE    /* Math result not representable */

#define    VTOP_ERR_OS_ENOTSOCK        ENOTSOCK    /* Socket operation on non-socket */
#define    VTOP_ERR_OS_EDESTADDRREQ    EDESTADDRREQ    /* Destination address required */
#define    VTOP_ERR_OS_EMSGSIZE        EMSGSIZE    /* Message too long */
#define    VTOP_ERR_OS_EPROTOTYPE        EPROTOTYPE    /* Protocol wrong type for socket */
#define    VTOP_ERR_OS_ENOPROTOOPT        ENOPROTOOPT    /* Protocol not available */
#define    VTOP_ERR_OS_EPROTONOSUPPORT    EPROTONOSUPPORT    /* Protocol not supported */
#define    VTOP_ERR_OS_ESOCKTNOSUPPORT    ESOCKTNOSUPPORT    /* Socket type not supported */
#define    VTOP_ERR_OS_EOPNOTSUPP        EOPNOTSUPP    /* Operation not supported on transport endpoint */
#define    VTOP_ERR_OS_EPFNOSUPPORT    EPFNOSUPPORT    /* Protocol family not supported */
#define    VTOP_ERR_OS_EAFNOSUPPORT    EAFNOSUPPORT    /* Address family not supported by protocol */
#define    VTOP_ERR_OS_EADDRINUSE        EADDRINUSE    /* Address already in use */
#define    VTOP_ERR_OS_EADDRNOTAVAIL    EADDRNOTAVAIL    /* Cannot assign requested address */
#define    VTOP_ERR_OS_ENETDOWN        ENETDOWN    /* Network is down */
#define    VTOP_ERR_OS_ENETUNREACH        ENETUNREACH    /* Network is unreachable */
#define    VTOP_ERR_OS_ENETRESET        ENETRESET    /* Network dropped connection because of reset */
#define    VTOP_ERR_OS_ECONNABORTED    ECONNABORTED    /* Software caused connection abort */

#define    VTOP_ERR_OS_ECONNRESET        ECONNRESET    /* Connection reset by peer */
#define    VTOP_ERR_OS_ENOBUFS        ENOBUFS    /* No buffer space available */
#define    VTOP_ERR_OS_EISCONN        EISCONN    /* Transport endpoint is already connected */
#define    VTOP_ERR_OS_ENOTCONN        ENOTCONN    /* Transport endpoint is not connected */
#define    VTOP_ERR_OS_ESHUTDOWN        ESHUTDOWN    /* Cannot send after transport endpoint shutdown */
#define    VTOP_ERR_OS_ETOOMANYREFS    ETOOMANYREFS    /* Too many references: cannot splice */
#define    VTOP_ERR_OS_ETIMEDOUT        ETIMEDOUT    /* Connection timed out */
#define    VTOP_ERR_OS_ECONNREFUSED    ECONNREFUSED    /* Connection refused */
#define    VTOP_ERR_OS_EHOSTDOWN        EHOSTDOWN    /* Host is down */
#define    VTOP_ERR_OS_EHOSTUNREACH    EHOSTUNREACH    /* No route to host */
#define    VTOP_ERR_OS_EALREADY        EALREADY    /* Operation already in progress */
#define    VTOP_ERR_OS_EINPROGRESS        EINPROGRESS    /* Operation now in progress */

#ifndef WIN32

#define    VTOP_ERR_OS_EDEADLK        EDEADLK    /* Resource deadlock would occur */
#define    VTOP_ERR_OS_ENAMETOOLONG    ENAMETOOLONG    /* File name too long */
#define    VTOP_ERR_OS_ENOLCK        ENOLCK    /* No record locks available */
#define    VTOP_ERR_OS_ENOSYS        ENOSYS    /* Function not implemented */
#define    VTOP_ERR_OS_ENOTEMPTY         ENOTEMPTY    /* Directory not empty */
#define    VTOP_ERR_OS_ELOOP        ELOOP    /* Too many symbolic links encountered */
#define    VTOP_ERR_OS_EWOULDBLOCK            VTOP_ERR_OS_EAGAIN    /* Operation would block */
#define    VTOP_ERR_OS_ENOMSG        ENOMSG    /* No message of desired type */
#define    VTOP_ERR_OS_EIDRM        EIDRM    /* Identifier removed */
#define    VTOP_ERR_OS_ECHRNG        ECHRNG    /* Channel number out of range */
#define    VTOP_ERR_OS_EL2NSYNC        EL2NSYNC    /* Level 2 not synchronized */
#define    VTOP_ERR_OS_EL3HLT        EL3HLT    /* Level 3 halted */
#define    VTOP_ERR_OS_EL3RST        EL3RST    /* Level 3 reset */
#define    VTOP_ERR_OS_ELNRNG        ELNRNG    /* Link number out of range */
#define    VTOP_ERR_OS_EUNATCH        EUNATCH    /* Protocol driver not attached */
#define    VTOP_ERR_OS_ENOCSI        ENOCSI    /* No CSI structure available */
#define    VTOP_ERR_OS_EL2HLT        EL2HLT    /* Level 2 halted */
#define    VTOP_ERR_OS_EBADE        EBADE    /* Invalid exchange */
#define    VTOP_ERR_OS_EBADR        EBADR    /* Invalid request descriptor */
#define    VTOP_ERR_OS_EXFULL        EXFULL    /* Exchange full */
#define    VTOP_ERR_OS_ENOANO        ENOANO    /* No anode */
#define    VTOP_ERR_OS_EBADRQC        EBADRQC    /* Invalid request code */
#define    VTOP_ERR_OS_EBADSLT        EBADSLT    /* Invalid slot */        
#define    VTOP_ERR_OS_EDEADLOCK         EDEADLOCK       
#define    VTOP_ERR_OS_EBFONT        EBFONT    /* Bad font file format */
#define    VTOP_ERR_OS_ENOSTR        ENOSTR    /* Device not a stream */
#define    VTOP_ERR_OS_ENODATA        ENODATA    /* No data available */
#define    VTOP_ERR_OS_ETIME        ETIME    /* Timer expired */
#define    VTOP_ERR_OS_ENOSR        ENOSR    /* Out of streams resources */
#define    VTOP_ERR_OS_ENONET        ENONET    /* Machine is not on the network */
#define    VTOP_ERR_OS_ENOPKG        ENOPKG    /* Package not installed */
#define    VTOP_ERR_OS_EREMOTE        EREMOTE    /* Object is remote */
#define    VTOP_ERR_OS_ENOLINK        ENOLINK    /* Link has been severed */
#define    VTOP_ERR_OS_EADV        EADV    /* Advertise error */
#define    VTOP_ERR_OS_ESRMNT        ESRMNT    /* Srmount error */
#define    VTOP_ERR_OS_ECOMM        ECOMM    /* Communication error on send */
#define    VTOP_ERR_OS_EPROTO        EPROTO    /* Protocol error */
#define    VTOP_ERR_OS_EMULTIHOP        EMULTIHOP    /* Multihop attempted */
#define    VTOP_ERR_OS_EDOTDOT        EDOTDOT    /* RFS specific error */
#define    VTOP_ERR_OS_EBADMSG        EBADMSG    /* Not a data message */
#define    VTOP_ERR_OS_EOVERFLOW        EOVERFLOW    /* Value too large for defined data type */
#define    VTOP_ERR_OS_ENOTUNIQ        ENOTUNIQ    /* Name not unique on network */
#define    VTOP_ERR_OS_EBADFD        EBADFD    /* File descriptor in bad state */
#define    VTOP_ERR_OS_EREMCHG        EREMCHG    /* Remote address changed */
#define    VTOP_ERR_OS_ELIBACC        ELIBACC    /* Can not access a needed shared library */
#define    VTOP_ERR_OS_ELIBBAD        ELIBBAD    /* Accessing a corrupted shared library */
#define    VTOP_ERR_OS_ELIBSCN        ELIBSCN    /* .lib section in a.out corrupted */
#define    VTOP_ERR_OS_ELIBMAX        ELIBMAX    /* Attempting to link in too many shared libraries */
#define    VTOP_ERR_OS_ELIBEXEC        ELIBEXEC    /* Cannot exec a shared library directly */
#define    VTOP_ERR_OS_EILSEQ        EILSEQ    /* Illegal byte sequence */
#define    VTOP_ERR_OS_ERESTART        ERESTART    /* Interrupted system call should be restarted */
#define    VTOP_ERR_OS_ESTRPIPE        ESTRPIPE    /* Streams pipe error */
#define    VTOP_ERR_OS_EUSERS        EUSERS    /* Too many users */


#define    VTOP_ERR_OS_ESTALE        ESTALE    /* Stale NFS file handle */
#define    VTOP_ERR_OS_EUCLEAN        EUCLEAN    /* Structure needs cleaning */
#define    VTOP_ERR_OS_ENOTNAM        ENOTNAM    /* Not a XENIX named type file */
#define    VTOP_ERR_OS_ENAVAIL        ENAVAIL    /* No XENIX semaphores available */
#define    VTOP_ERR_OS_EISNAM        EISNAM    /* Is a named type file */
#define    VTOP_ERR_OS_EREMOTEIO        EREMOTEIO    /* Remote I/O error */
#define    VTOP_ERR_OS_EDQUOT        EDQUOT    /* Quota exceeded */        
#define    VTOP_ERR_OS_ENOMEDIUM        ENOMEDIUM    /* No medium found */
#define    VTOP_ERR_OS_EMEDIUMTYPE        EMEDIUMTYPE    /* Wrong medium type */


#else
#define VTOP_ERR_OS_EDEADLK         36
#define VTOP_ERR_OS_ENAMETOOLONG    38
#define VTOP_ERR_OS_ENOLCK          39
#define VTOP_ERR_OS_ENOSYS          40
#define VTOP_ERR_OS_ENOTEMPTY       41
#define VTOP_ERR_OS_EILSEQ          42
//#define    VTOP_ERR_OS_ETIMEDOUT       43

/*
 * All Windows Sockets error constants are biased by VTOP_WSABASEERR from
 * the "normal"
 */
#define VTOP_WSABASEERR              10000
/*
 * Windows Sockets definitions of regular Microsoft C error constants
 */
#define VTOP_WSAEINTR                (VTOP_WSABASEERR+4)
#define VTOP_WSAEBADF                (VTOP_WSABASEERR+9)
#define VTOP_WSAEACCES               (VTOP_WSABASEERR+13)
#define VTOP_WSAEFAULT               (VTOP_WSABASEERR+14)
#define VTOP_WSAEINVAL               (VTOP_WSABASEERR+22)
#define VTOP_WSAEMFILE               (VTOP_WSABASEERR+24)

/*
 * Windows Sockets definitions of regular Berkeley error constants
 */
#define VTOP_WSAEWOULDBLOCK          (VTOP_WSABASEERR+35)
#define VTOP_WSAEINPROGRESS          (VTOP_WSABASEERR+36)
#define VTOP_WSAEALREADY             (VTOP_WSABASEERR+37)
#define VTOP_WSAENOTSOCK             (VTOP_WSABASEERR+38)
#define VTOP_WSAEDESTADDRREQ         (VTOP_WSABASEERR+39)
#define VTOP_WSAEMSGSIZE             (VTOP_WSABASEERR+40)
#define VTOP_WSAEPROTOTYPE           (VTOP_WSABASEERR+41)
#define VTOP_WSAENOPROTOOPT          (VTOP_WSABASEERR+42)
#define VTOP_WSAEPROTONOSUPPORT      (VTOP_WSABASEERR+43)
#define VTOP_WSAESOCKTNOSUPPORT      (VTOP_WSABASEERR+44)
#define VTOP_WSAEOPNOTSUPP           (VTOP_WSABASEERR+45)
#define VTOP_WSAEPFNOSUPPORT         (VTOP_WSABASEERR+46)
#define VTOP_WSAEAFNOSUPPORT         (VTOP_WSABASEERR+47)
#define VTOP_WSAEADDRINUSE           (VTOP_WSABASEERR+48)
#define VTOP_WSAEADDRNOTAVAIL        (VTOP_WSABASEERR+49)
#define VTOP_WSAENETDOWN             (VTOP_WSABASEERR+50)
#define VTOP_WSAENETUNREACH          (VTOP_WSABASEERR+51)
#define VTOP_WSAENETRESET            (VTOP_WSABASEERR+52)
#define VTOP_WSAECONNABORTED         (VTOP_WSABASEERR+53)
#define VTOP_WSAECONNRESET           (VTOP_WSABASEERR+54)
#define VTOP_WSAENOBUFS              (VTOP_WSABASEERR+55)
#define VTOP_WSAEISCONN              (VTOP_WSABASEERR+56)
#define VTOP_WSAENOTCONN             (VTOP_WSABASEERR+57)
#define VTOP_WSAESHUTDOWN            (VTOP_WSABASEERR+58)
#define VTOP_WSAETOOMANYREFS         (VTOP_WSABASEERR+59)
#define VTOP_WSAETIMEDOUT            (VTOP_WSABASEERR+60)
#define VTOP_WSAECONNREFUSED         (VTOP_WSABASEERR+61)
#define VTOP_WSAELOOP                (VTOP_WSABASEERR+62)
#define VTOP_WSAENAMETOOLONG         (VTOP_WSABASEERR+63)
#define VTOP_WSAEHOSTDOWN            (VTOP_WSABASEERR+64)
#define VTOP_WSAEHOSTUNREACH         (VTOP_WSABASEERR+65)
#define VTOP_WSAENOTEMPTY            (VTOP_WSABASEERR+66)
#define VTOP_WSAEPROCLIM             (VTOP_WSABASEERR+67)
#define VTOP_WSAEUSERS               (VTOP_WSABASEERR+68)
#define VTOP_WSAEDQUOT               (VTOP_WSABASEERR+69)
#define VTOP_WSAESTALE               (VTOP_WSABASEERR+70)
#define VTOP_WSAEREMOTE              (VTOP_WSABASEERR+71)

/*
 * Extended Windows Sockets error constant definitions
 */
#define VTOP_WSASYSNOTREADY          (VTOP_WSABASEERR+91)
#define VTOP_WSAVERNOTSUPPORTED      (VTOP_WSABASEERR+92)
#define VTOP_WSANOTINITIALISED       (VTOP_WSABASEERR+93)
#define VTOP_WSAEDISCON              (VTOP_WSABASEERR+101)
#define VTOP_WSAENOMORE              (VTOP_WSABASEERR+102)
#define VTOP_WSAECANCELLED           (VTOP_WSABASEERR+103)
#define VTOP_WSAEINVALIDPROCTABLE    (VTOP_WSABASEERR+104)
#define VTOP_WSAEINVALIDPROVIDER     (VTOP_WSABASEERR+105)
#define VTOP_WSAEPROVIDERFAILEDINIT  (VTOP_WSABASEERR+106)
#define VTOP_WSASYSCALLFAILURE       (VTOP_WSABASEERR+107)
#define VTOP_WSASERVICE_NOT_FOUND    (VTOP_WSABASEERR+108)
#define VTOP_WSATYPE_NOT_FOUND       (VTOP_WSABASEERR+109)
#define VTOP_WSA_E_NO_MORE           (VTOP_WSABASEERR+110)
#define VTOP_WSA_E_CANCELLED         (VTOP_WSABASEERR+111)
#define VTOP_WSAEREFUSED             (VTOP_WSABASEERR+112)

/*
 * Error return codes from gethostbyname() and gethostbyaddr()
 * (when using the resolver). Note that these errors are
 * retrieved via VTOP_WSAGetLastError() and must therefore follow
 * the rules for avoiding clashes with error numbers from
 * specific implementations or language run-time systems.
 * For this reason the codes are based at VTOP_WSABASEERR+1001.
 * Note also that [VTOP_WSA]NO_ADDRESS is defined only for
 * compatibility purposes.
 */


/* Authoritative Answer: Host not found */
#define VTOP_WSAHOST_NOT_FOUND       (VTOP_WSABASEERR+1001)
#define VTOP_HOST_NOT_FOUND          VTOP_WSAHOST_NOT_FOUND

/* Non-Authoritative: Host not found, or SERVERFAIL */
#define VTOP_WSATRY_AGAIN            (VTOP_WSABASEERR+1002)
#define VTOP_TRY_AGAIN               VTOP_WSATRY_AGAIN

/* Non-recoverable errors, FORMERR, REFUSED, NOTIMP */
#define VTOP_WSANO_RECOVERY          (VTOP_WSABASEERR+1003)
#define VTOP_NO_RECOVERY             VTOP_WSANO_RECOVERY

/* Valid name, no data record of requested type */
#define VTOP_WSANO_DATA              (VTOP_WSABASEERR+1004)
#define VTOP_NO_DATA                 VTOP_WSANO_DATA

/* no address, look for MX record */
#define VTOP_WSANO_ADDRESS           VTOP_WSANO_DATA
#define VTOP_NO_ADDRESS              VTOP_WSANO_ADDRESS


#define VTOP_WSA_QOS_TMP_D        1000

#define  VTOP_WSA_QOS_RECEIVERS               (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 5)

#define  VTOP_WSA_QOS_SENDERS                 (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 6)

#define  VTOP_WSA_QOS_NO_SENDERS              (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 7)  

#define  VTOP_WSA_QOS_NO_RECEIVERS            (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 8) 

#define  VTOP_WSA_QOS_REQUEST_CONFIRMED       (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 9)

#define  VTOP_WSA_QOS_ADMISSION_FAILURE       (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 10)

#define  VTOP_WSA_QOS_POLICY_FAILURE          (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 11)

#define  VTOP_WSA_QOS_BAD_STYLE               (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 12)

#define  VTOP_WSA_QOS_BAD_OBJECT              (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 13)

#define  VTOP_WSA_QOS_TRAFFIC_CTRL_ERROR      (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 14)

#define  VTOP_WSA_QOS_GENERIC_ERROR           (VTOP_WSABASEERR + VTOP_WSA_QOS_TMP_D + 15) 


/*
 * Windows Sockets errors redefined as regular Berkeley error constants.
 * These are commented out in Windows NT to avoid conflicts with errno.h.
 * Use the VTOP_WSA constants instead.
 */

#define VTOP_EWOULDBLOCK             VTOP_WSAEWOULDBLOCK
#define VTOP_EINPROGRESS             VTOP_WSAEINPROGRESS
#define VTOP_EALREADY                VTOP_WSAEALREADY
#define VTOP_ENOTSOCK                VTOP_WSAENOTSOCK
#define VTOP_EDESTADDRREQ            VTOP_WSAEDESTADDRREQ
#define VTOP_EMSGSIZE                VTOP_WSAEMSGSIZE
#define VTOP_EPROTOTYPE              VTOP_WSAEPROTOTYPE
#define VTOP_ENOPROTOOPT             VTOP_WSAENOPROTOOPT
#define VTOP_EPROTONOSUPPORT         VTOP_WSAEPROTONOSUPPORT
#define VTOP_ESOCKTNOSUPPORT         VTOP_WSAESOCKTNOSUPPORT
#define VTOP_EOPNOTSUPP              VTOP_WSAEOPNOTSUPP
#define VTOP_EPFNOSUPPORT            VTOP_WSAEPFNOSUPPORT
#define VTOP_EAFNOSUPPORT            VTOP_WSAEAFNOSUPPORT
#define VTOP_EADDRINUSE              VTOP_WSAEADDRINUSE
#define VTOP_EADDRNOTAVAIL           VTOP_WSAEADDRNOTAVAIL
#define VTOP_ENETDOWN                VTOP_WSAENETDOWN
#define VTOP_ENETUNREACH             VTOP_WSAENETUNREACH
#define VTOP_ENETRESET               VTOP_WSAENETRESET
#define VTOP_ECONNABORTED            VTOP_WSAECONNABORTED
#define VTOP_ECONNRESET              VTOP_WSAECONNRESET
#define VTOP_ENOBUFS                 VTOP_WSAENOBUFS
#define VTOP_EISCONN                 VTOP_WSAEISCONN
#define VTOP_ENOTCONN                VTOP_WSAENOTCONN
#define VTOP_ESHUTDOWN               VTOP_WSAESHUTDOWN
#define VTOP_ETOOMANYREFS            VTOP_WSAETOOMANYREFS
#define VTOP_ETIMEDOUT               VTOP_WSAETIMEDOUT
#define VTOP_ECONNREFUSED            VTOP_WSAECONNREFUSED
#define VTOP_ELOOP                   VTOP_WSAELOOP
#define VTOP_ENAMETOOLONG            VTOP_WSAENAMETOOLONG
#define VTOP_EHOSTDOWN               VTOP_WSAEHOSTDOWN
#define VTOP_EHOSTUNREACH            VTOP_WSAEHOSTUNREACH
#define VTOP_ENOTEMPTY               VTOP_WSAENOTEMPTY
#define VTOP_EPROCLIM                VTOP_WSAEPROCLIM
#define VTOP_EUSERS                  VTOP_WSAEUSERS
#define VTOP_EDQUOT                  VTOP_WSAEDQUOT
#define VTOP_ESTALE                  VTOP_WSAESTALE
#define VTOP_EREMOTE                 VTOP_WSAEREMOTE
#endif

/*��ʷ��������*/
typedef enum tagVTOP_E_OPERATE_TYPE
{
    VTOP_E_OPERATE_NONE = 0,
    VTOP_E_OPERATE_CREATE_TIMER,
    VTOP_E_OPERATE_FREE_TIMER,
}VTOP_E_OPERATE_TYPE;

/*��ʷ������¼*/
#define VTOP_E_THREAD_NAME_MAX_SIZE    32
typedef struct tagVTOP_OperateRec
{
    VOS_UINT32 ulType;
    VOS_INT32 lTickTime;
    VOS_INT32 lTid;
    VOS_CHAR szThreadName[VTOP_E_THREAD_NAME_MAX_SIZE];
    VOS_UINT32 ulParam1;
    VOS_UINT32 ulParam2;
}VTOP_S_OperateRec;

/*��ʷ�����б�*/
#define VTOP_E_OP_ARRAY_MAX_SIZE    512
typedef struct tagVTOP_OperateHistory
{
    VTOP_S_OperateRec astOpArray[VTOP_E_OP_ARRAY_MAX_SIZE];
    VOS_INT32 lCurPos;
}VTOP_S_OperateHistory;

TUP_API VOS_UINT32 VTOP_InitOperateHistory();
TUP_API VOS_VOID VTOP_AddOperateRec(VTOP_S_OperateRec *pstOperateRec);
TUP_API VOS_VOID VTOP_DumpOperateHistory(VOS_CHAR *pszBuffer, VOS_INT32 lLen);


/*����errno*/
TUP_API VOS_INT VTOP_GetLastErr(VOS_VOID);
/*����errno*/
TUP_API VOS_VOID VTOP_SetLastErr(VOS_INT newErrNo);
/*����socket errno*/
TUP_API VOS_INT VTOP_GetLastSocketErr(VOS_VOID);

/*��ȡ��������Ϣ*/
TUP_API VOS_CHAR * VTOP_StrError(VOS_INT errNo);

/*��ȡ��������Ϣ��������汾*/
TUP_API VOS_INT32 VTOP_StrError_S(VOS_CHAR *buf, VTOP_SIZE_T bufLen, VOS_INT errNo);



#endif /* __OS_ERR_INTERFACE_H__ */

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cpluscplus */
#endif /* __cpluscplus */

