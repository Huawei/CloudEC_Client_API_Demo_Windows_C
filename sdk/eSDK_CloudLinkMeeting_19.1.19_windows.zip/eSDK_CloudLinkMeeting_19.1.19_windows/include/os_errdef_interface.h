/*****************************************************************************/
/*                                                                           */
/*                Copyright 2004 - 2050, Huawei Tech. Co., Ltd.              */
/*                           ALL RIGHTS RESERVED                             */
/*                                                                           */
/* FileNmae: vtoperrdef.h                                                    */
/* Version : 1.0                                                             */
/*                                                                           */
/* Description:                                                              */
/*                                                                           */
/* History:                                                                  */
/*****************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif /* __cpluscplus */
#endif /* __cpluscplus */

#ifndef __VTOP_ERRDEF_H__
#define __VTOP_ERRDEF_H__

#define VTOP_ERR_APPID         0x80UL

typedef enum vtopVTOP_E_MID_DEFINE
{
    MID_FS    = 1,
    MID_MT,
    MID_RTP,
    MID_WV,
    MID_PMEP,
    MID_SIPADP,

    MID_PUSH = 10,
    MID_ROAP,
    MID_MSRP,
    MID_XCAP,
    MID_PRESENCE,
    MID_IM,

    MID_SYSM = 20,
    MID_DEVM,
    MID_MSG,
    MID_APPM,
    MID_LOAD,
    MID_UPGRD,
    MID_CFM,
    MID_CLI,
    MID_WDT,
    MID_LOG,
    MID_EXCEPT,
    MID_APPMER,
    MID_XMODEM,
    MID_DOT1X,
    MID_EMGT_UPG,
    /* BEGIN add: [[TUP V100R001C01] [BlackBox] [2013/1/7] [   (   )]] 
       �޸�ԭ��: ���Ӻ�ϻ��ģ��ID��CPUռ���ʼ��ģ��ID */
    MID_EXC,
    MID_CPUDET,
    /* END   add: [[TUP V100R001C01] [BlackBox] [2013/1/7] [   (   )]] */
    
    MID_BUTT
}VTOP_E_MID_DEFINE;

/*
typedef enum vtopVTOP_E_ERRLEVEL
{
    ERR_LEVEL_1,
    ERR_LEVEL_2,
    ERR_LEVEL_3,
    ERR_LEVEL_4,
    ERR_LEVEL_5,
    ERR_LEVEL_6,
    ERR_LEVEL_7,
    ERR_LEVEL_8
}VTOP_E_ERRLEVEL;
*/
typedef enum vtopLOG_E_ERRLEVEL
{
    VTOP_LOG_LEVEL_DEBUG = 0,    /* debug-level                                  */
    VTOP_LOG_LEVEL_INFO,         /* informational                                */
    VTOP_LOG_LEVEL_NOTICE,       /* normal but significant condition             */
    VTOP_LOG_LEVEL_WARNING,      /* warning conditions                           */
    VTOP_LOG_LEVEL_ERROR,        /* error conditions                             */
    VTOP_LOG_LEVEL_CRIT,         /* critical conditions                          */
    VTOP_LOG_LEVEL_ALERT,        /* action must be taken immediately             */
    VTOP_LOG_LEVEL_FATAL,        /* just for compatibility with previous version */
    VTOP_LOG_LEVEL_BUTT
}VTOP_E_ERRLEVEL;

#define VTOP_DEF_ERR( mid, level, errid) \
    ( ((VTOP_ERR_APPID)<<24) | ((mid) << 16 ) | ((level)<<13) | (errid) )

/*
#define VTOP_DEF_ERR( mid, type,level, errid) \
    ( ((VTOP_ERR_APPID)<<24) | ((mid) << 17 ) |((type)<<13)| ((level)<<10) | (errid) )
 */   
#endif /* __VTOP_ERRDEF_H__ */

#ifdef __cplusplus
#if __cplusplus
}
#endif /* __cpluscplus */
#endif /* __cpluscplus */

