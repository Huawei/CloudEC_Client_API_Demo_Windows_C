﻿#ifndef __TSDK_UI_PLUGIN_DEF_H__
#define __TSDK_UI_PLUGIN_DEF_H__


#include "tsdk_def.h"
#include "tsdk_manager_def.h"
#include "tsdk_conference_def.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


/**
 * [en]This enumeration is used to describe UI plugin version type.
 * [cn]UI插件版本类型
 */
typedef enum tagTSDK_E_UI_PLUGIN_VERSION
{
    TSDK_E_UI_PLUGIN_BASE,                  /**< [en]Indicates common basic device.
                                                 [cn]普通基础设备 */
    TSDK_E_UI_PLUGIN_BIG_CONF               /**< [en]Indicates large screen device (Reserved, not supported).
                                                 [cn][预留，暂不支持]大屏设备 */
}TSDK_E_UI_PLUGIN_VERSION;


/**
 * [en]This enumeration is used to describe the type of layout.
 * [cn]布局类型
 */
typedef enum tagTSDK_E_LAYOUT_TYPE
{
    TSDK_E_LAYOUT_AVC_AUDIO = 0,            /**< [en]Indicates AVC audio.
                                                 [cn]单流-音频 */
    TSDK_E_LAYOUT_AVC_VIDEO,                /**< [en]Indicates AVC video.
                                                 [cn]单流-视频 */
    TSDK_E_LAYOUT_SVC_SPEAKER,              /**< [en]Indicates SVC speaker.
                                                 [cn]多流-演讲者模式 */
    TSDK_E_LAYOUT_SVC_GALLERY,              /**< [en]Indicates SVC gallery.
                                                 [cn]多流-画廊模式 */
    TSDK_E_LAYOUT_SVC_PICINPIC,             /**< [en]Indicates SVC picinpic.
                                                 [cn]多流-画中画模式 */
    TSDK_E_LAYOUT_SVC_AUX,                  /**< [en]Indicates SVC auxiliarv.
                                                 [cn]多流-辅流 */
    TSDK_E_LAYOUT_SVC_FLOAT_MINI,           /**< [en]Indicates SVC floating window - minimum, with title bar/restoration.
                                                 [cn]多流浮动窗口-最小化,有标题栏/还原 */
    TSDK_E_LAYOUT_SVC_FLOAT_ONE,            /**< [en]Indicates SVC floating window – one video.
                                                 [cn]多流浮动窗口-一个视频 */
    TSDK_E_LAYOUT_SVC_FLOAT_GALLERY,        /**< [en]Indicates SVC floating window – vertical.
                                                 [cn]多流浮动窗口-竖排 */
    TSDK_E_LAYOUT_SVC_FLOAT_BIG_ONE,        /**< [en]Indicates SVC floating window - a large video window.
                                                 [cn]多流浮动窗口-一个视频大窗口 */
    TSDK_E_LAYOUT_SVC_AUX_FLOAT,            /**< [en]Indicates SVC auxiliarv floating window.
                                                 [cn]辅流悬浮窗 */
    TSDK_E_LAYOUT_SVC_FLOAT,                /**< [en]Indicates SVC - common minimize window.
                                                 [cn]多流-普通最小化窗口 */
    TSDK_E_LAYOUT_AVC_AUX,                  /**< [en]Indicates AVC auxiliarv.
                                                 [cn]单流-辅流 */
    TSDK_E_LAYOUT_AVC_FLOAT_MINI,           /**< [en]Indicates AVC floating window - minimum, with title bar/restoration.
                                                 [cn]单流浮动窗口-最小化,有标题栏/还原 */
    TSDK_E_LAYOUT_AVC_FLOAT_ONE,            /**< [en]Indicates AVC floating window – one video.
                                                 [cn]单流浮动窗口-一个视频 */
    TSDK_E_LAYOUT_AVC_FLOAT_BIG_ONE,        /**< [en]Indicates AVC floating window - a large video window.
                                                 [cn]单流浮动窗口-一个视频大窗口 */
    TSDK_E_LAYOUT_AVC_AUX_FLOAT,            /**< [en]Indicates AVC auxiliarv floating window.
                                                 [cn]单流中辅流悬浮窗 */
    TSDK_E_LAYOUT_AVC_FLOAT,                /**< [en]Indicates AVC - common minimize window.
                                                 [cn]单流-普通最小化窗口 */
    TSDK_E_LAYOUT_BUTT
}TSDK_E_LAYOUT_TYPE;



/**
 * [en]This enumeration is used to describe UI button type (Only the definition of the button type that needs to be set externally is provided.) 
 * [cn]UI按钮类型(仅提供需要外部设置状态的按钮类型定义)
 */
typedef enum tagTSDK_E_UI_BUTTON_TYPE
{
    TSDK_E_UI_BUTTON_MIC,                   /**< [en]Indicates microphone.
                                                 [cn]麦克风 */
    TSDK_E_UI_BUTTON_CAMERA,                /**< [en]Indicates camera .
                                                 [cn]摄像头 */
    TSDK_E_UI_BUTTON_SPEAKER,               /**< [en]Indicates speaker.
                                                 [cn]扬声器 */
    TSDK_E_UI_BUTTON_INVITE_MEMBER,         /**< [en]Indicates inviting a member.
                                                 [cn]邀请成员 */
    TSDK_E_UI_BUTTON_DISPLAY_MEMBER_LIST,   /**< [en]Indicates display the member list.
                                                 [cn]显示成员列表 */
    TSDK_E_UI_BUTTON_BUTT
}TSDK_E_UI_BUTTON_TYPE;


/**
* [en]This enumeration is used to describe UI window size.
* [cn]UI窗口大小
*/
typedef enum tagTSDK_E_UI_WINDOW_SIZE
{
    TSDK_E_UI_WINDOW_NORMAL,           /**< [en]Indicates normal.
                                            [cn]通常 */
    TSDK_E_UI_WINDOW_MAXSIZE,          /**< [en]Indicates maxsize.
                                            [cn]最大化 */
    TSDK_E_UI_WINDOW_FULLSCREEN,       /**< [en]Indicates fullscreen.
                                            [cn]全屏 */
    TSDK_E_UI_WINDOW_FLOAT,            /**< [en]Indicates float.
                                            [cn]浮动窗口 */
    TSDK_E_UI_WINDOW_INVALID,          /**< [en]Indicates invalid.
                                            [cn]无效 */
    TSDK_E_UI_WINDOW_BUTT
}TSDK_E_UI_WINDOW_SIZE;


/**
 * [en]This enumeration is used to describe the type of event further processing.
 * [cn]事件进一步处理类型
 */
typedef enum tagTSDK_E_FURTHER_PROCESS_TYPE
{
    TSDK_E_FURTHER_PROCESS_SYNC_INFO,       /**< [en]Indicates the application program synchronizes the corresponding status information as required.
                                                 [cn]应用程序根据需要同步相应的状态信息 */
    TSDK_E_FURTHER_PROCESS_LOGICAL_CALL     /**< [en]Indicates the application needs to invoke the corresponding logic to ensure that the service is complete..
                                                 [cn]应用程序需要进行相应的逻辑调用，以保证业务完成 */
}TSDK_E_FURTHER_PROCESS_TYPE;


/**
 * [en]This enumeration is used to describe resource language type.
 * [cn]文字资源的语言类型
 */
typedef enum tagTSDK_E_RESOURCE_LANGUAGE_TYPE
{
    TSDK_E_RESOURCE_LANGUAGE_ZH,                       /**< [en]Indicates Chinese.
                                                            [cn]中文 */
    TSDK_E_RESOURCE_LANGUAGE_EN,                       /**< [en]Indicates English.
                                                            [cn]英语 */
    TSDK_E_RESOURCE_LANGUAGE_PT,                       /**< [en]Indicates Portuguese.
                                                            [cn]葡萄牙语 */
    TSDK_E_RESOURCE_LANGUAGE_FR,                       /**< [en]Indicates French.
                                                            [cn]法语 */
    TSDK_E_RESOURCE_LANGUAGE_RU,                       /**< [en]Indicates Russian.
                                                            [cn]俄语 */
    TSDK_E_RESOURCE_LANGUAGE_TR,                       /**< [en]Indicates Turkey.
                                                            [cn]土耳其语 */
    TSDK_E_RESOURCE_LANGUAGE_PL,                       /**< [en]Indicates Polish (Not supported).
                                                            [cn]波兰语 暂不支持*/
    TSDK_E_RESOURCE_LANGUAGE_ITA,                      /**< [en]Indicates Italian (Italy).
                                                            [cn]意大利语（意大利） */
    TSDK_E_RESOURCE_LANGUAGE_PTB,                      /**< [en]Indicates Portuguese (Brazil).
                                                            [cn]葡萄牙语（巴西） */
    TSDK_E_RESOURCE_LANGUAGE_THA,                      /**< [en]Indicates Thai (Thailand).
                                                            [cn]泰语（泰国） */
    TSDK_E_RESOURCE_LANGUAGE_ESM,                      /**< [en]Indicates Spanish (Mexico).
                                                            [cn]西班牙语（墨西哥） */
    TSDK_E_RESOURCE_LANGUAGE_ZHH,                      /**< [en]Indicates Chinese (Hong Kong Special Administrative Region, China).
                                                            [cn]中文（香港特别行政区，中国） */
    TSDK_E_RESOURCE_LANGUAGE_ESN,                      /**< [en]Indicates Spanish (Spain).
                                                            [cn]西班牙语（西班牙） */
    TSDK_E_RESOURCE_LANGUAGE_BUTT
}TSDK_E_RESOURCE_LANGUAGE_TYPE;



/**
 * [en]This structure is used to describe UI plugin base info.
 * [cn]UI插件基础信息
 */
typedef struct tagTSDK_S_UI_PLUGIN_BASE_INFO
{
    TSDK_CHAR app_display_name[TSDK_D_MAX_APP_NAME_LEN + 1];        /**< [en]Indicates application display name.
                                                                         [cn]应用程序显示名 */
    TSDK_E_RESOURCE_LANGUAGE_TYPE language;                         /**< [en]Indicates language resource type.
                                                                         [cn]语言资源类型 */
    TSDK_E_UI_PLUGIN_VERSION plugin_version;                        /**< [en]Indicates UI plugin version.
                                                                         [cn]UI插件版本*/
    TSDK_CHAR resources_path[TSDK_D_MAX_RESOURCES_PATH_LEN + 1];    /**< [en]Indicates resources path.
                                                                         [cn]资源路径 */
    TSDK_CHAR user_files_path[TSDK_D_MAX_USER_FILES_PATH_LEN + 1];  /**< [en]Indicates user files path.
                                                                         [cn]用户文件路径 */
}TSDK_S_UI_PLUGIN_BASE_INFO;


/**
* [en]This structure is used to describe UI plugin window visible info.
* [cn]UI插件主窗口按钮可见信息
*/
typedef struct tagTSDK_S_UI_PLUGIN_MAIN_WINDOW_VISIBLE_INFO
{
    TSDK_BOOL hide_top_tool_bar;            /**< [en]Indicates whether to hide the top toolbar. TSDK_TRUE: Hidden. Default value: TSDK_FALSE.
                                                 [cn]是否隐藏上边栏，TSDK_TRUE 为隐藏，默认 TSDK_FALSE */
    TSDK_BOOL hide_bottom_tool_bar;         /**< [en]Indicates whether to hide the bottom toolbar. TSDK_TRUE: Hidden. Default value: TSDK_FALSE.
                                                 [cn]是否隐藏下边栏，TSDK_TRUE 为隐藏，默认 TSDK_FALSE */
    TSDK_BOOL hide_invite_button;           /**< [en]Indicates whether to hide the invite button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                 [cn]是否隐藏邀请按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
    TSDK_BOOL hide_attendees_button;        /**< [en]Indicates whether to hide the attendees button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                 [cn]是否隐藏与会者按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
    TSDK_BOOL hide_share_button;            /**< [en]Indicates whether to hide the share button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                 [cn]是否隐藏共享按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
    TSDK_BOOL hide_share_conf_link;         /**< [en]Indicates whether to hide the share conference link. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                 [cn]是否隐藏分享会议链接， TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
}TSDK_S_UI_PLUGIN_MAIN_WINDOW_VISIBLE_INFO;


/**
* [en]This structure is used to describe UI plugin window visible info.
* [cn]UI插件数据窗口按钮可见信息
*/
typedef struct tagTSDK_S_UI_PLUGIN_DATA_WINDOW_VISIBLE_INFO
{
    TSDK_BOOL hide_invite_button;                       /**< [en]Indicates whether to hide the invite button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                             [cn]是否隐藏邀请按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
    TSDK_BOOL hide_attendees_button;                    /**< [en]Indicates whether to hide the attendees button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                             [cn]是否隐藏与会者按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
    TSDK_BOOL hide_request_remote_control_button;       /**< [en]Indicates whether to hide the attendees button. TSDK_TRUE: Hidden. Default value: TSDK_TRUE.
                                                             [cn]是否隐藏请求远程控制菜单按钮，TSDK_TRUE 为隐藏，默认 TSDK_TRUE */
}TSDK_S_UI_PLUGIN_DATA_WINDOW_VISIBLE_INFO;


/**
* [en]This structure is used to describe UI plugin window visible info.
* [cn]UI插件按钮可见信息
*/
typedef struct tagTSDK_S_UI_PLUGIN_WINDOW_VISIBLE_INFO
{
    TSDK_S_UI_PLUGIN_MAIN_WINDOW_VISIBLE_INFO main_window_visible_info;     /**< [en]Indicates video window visible information.
                                                                                 [cn]视频窗口可见信息 */
    TSDK_S_UI_PLUGIN_DATA_WINDOW_VISIBLE_INFO data_window_visible_info;     /**< [en]Indicates data window visible information.
                                                                                 [cn]数据窗口可见信息 */
}TSDK_S_UI_PLUGIN_WINDOW_VISIBLE_INFO;


/**
 * [en]This structure is used to describe coordinate and size information.
 * [cn]坐标及大小信息
 */
typedef struct tagTSDK_S_COORDINATES_AND_SIZE_INFO
{
    TSDK_INT32 left_top_x;  /**< [en]Indicates the left_top_x coordinate.
                                 [cn]左上角x坐标 */
    TSDK_INT32 left_top_y;  /**< [en]Indicates the left_top_x coordinate.
                                 [cn]左上角y坐标*/
    TSDK_INT32 width;       /**< [en]Indicates the width.
                                 [cn]宽 */
    TSDK_INT32 height;      /**< [en]Indicates height.
                                 [cn]高 */
}TSDK_S_COORDINATES_AND_SIZE_INFO;



/**
 * [en]This structure is used to describe parent window process information .
 * [cn]父窗口进程信息
 */
typedef struct tagTSDK_S_PARENT_PROCESS_INFO
{
    TSDK_CHAR process_name[TSDK_D_MAX_APP_NAME_LEN + 1];   /**< [en]Indicates process name .
                                                                [cn]进程名 */
    TSDK_CHAR title[TSDK_D_MAX_WND_TITLE_LEN + 1];         /**< [en]Indicates title.
                                                                [cn]标题*/
    TSDK_INT32 x_offset;                                   /**< [en]Indicates x-axis offset relative to parent frame.
                                                                [cn]相对于父Frame x轴偏移 */
    TSDK_INT32 y_offset;                                   /**< [en]Indicates y-axis offset relative to parent frame.
                                                                [cn]相对于父Frame y轴偏移 */
    TSDK_INT32 x_offset_rate;                              /**< [en]Indicates x-axis offset ratio relative to parent frame during linkage.
                                                                [cn]联动时相对于父Frame x轴偏移率 */
    TSDK_INT32 y_offset_rate;                              /**< [en]Indicates y-axis offset ratio relative to parent frame during linkage.
                                                                [cn]联动时相对于父Frame y轴偏移率 */
    TSDK_BOOL is_need_attach;                              /**< [en]Indicates whether linkage or not.
                                                                [cn]是否联动*/
}TSDK_S_PARENT_PROCESS_INFO;



/**
 * [en]This structure is used to describe UI plugin frame parameters.
 * [cn]UI插件Frame参数
 */
typedef struct tagTSDK_S_UI_PLUGIN_FRAME_PARAM
{
    TSDK_BOOL has_frame_info;                                   /**< [en]Indicates whether the frame information exists.
                                                                     [cn]是否有FRAME信息*/
    TSDK_S_COORDINATES_AND_SIZE_INFO frame_info;                /**< [en]Indicates frame information. This parameter is valid only when has_frame_info is set to TSDK_TRUE. Otherwise, it is used the default value.
                                                                     [cn]FRAME信息，has_frame_info 为TSDK_TRUE有效，否则使用默认值 */
    TSDK_BOOL has_parent_wnd;                                   /**< [en]Indicates whether a parent window exists.
                                                                     [cn]是否有父窗口*/
    TSDK_S_PARENT_PROCESS_INFO parent_info;                     /**< [en]Indicates process information in the parent window. This parameter is valid only when has_parent_wnd is set to TSDK_TRUE.
                                                                     [cn]父窗口进程信息，has_parent_wnd 为TSDK_TRUE有效 */
}TSDK_S_UI_PLUGIN_FRAME_PARAM;


/**
 * [en]This structure is used to describe UI plugin hwnd info.
 * [cn]UI插件Frame句柄信息
 */
typedef struct tagTSDK_S_UI_PLUGIN_FRAME_HWND_INFO
{
    TSDK_UPTR base_frame_hwnd;                                  /**< [en]Indicates video frame handle.
                                                                     [cn]视频Frame 句柄*/
    TSDK_UPTR local_video_wnd_hwnd;                             /**< [en]Indicates local video window handle.
                                                                     [cn]本地视频窗口句柄*/
    TSDK_UPTR remote_video_wnd_hwnd;                            /**< [en]Indicates remote video window handle.
                                                                     [cn]远端视频窗口句柄*/
}TSDK_S_UI_PLUGIN_FRAME_HWND_INFO;


/**
* [en]This structure is used to describe UI plugin hwnd info.
* [cn]UI插件窗口大小和相对位置参数
*/
typedef struct tagTSDK_S_UI_PLUGIN_WND_SIZE_PARAM
{
    TSDK_UPTR frame_hwnd;          /**< [en]Indicates frame window handle.
                                        [cn]Frame窗口 句柄*/

    TSDK_BOOL has_wnd_size;        /**< [en]Indicates whether to set the window size.
                                        [cn]是否设置窗口大小*/
    TSDK_INT32 width;              /**< [en]Indicates the width.
                                        [cn]宽 */
    TSDK_INT32 height;             /**< [en]Indicates height.
                                        [cn]高 */

    TSDK_BOOL has_relative_pos;    /**< [en]Indicates whether to set the offset ratio.
                                        [cn]是否设置偏移比例*/
    TSDK_INT32 x_offset_rate;      /**< [en]Indicates x-axis offset ratio relative to parent window during linkage.
                                        [cn]联动时x坐标相对父窗口偏移比例 */
    TSDK_INT32 y_offset_rate;      /**< [en]Indicates y-axis offset ratio relative to parent window during linkage.
                                        [cn]联动时y坐标相对父窗口偏移比例 */


}TSDK_S_UI_PLUGIN_WND_SIZE_PARAM;


/**
 * [en]This structure is used to describe microphone button status information.
 * [cn]麦克风按钮状态信息
 */
typedef struct tagTSDK_S_MIC_BUTTON_STATE_INFO
{
    TSDK_BOOL is_mute;                                          /**< [en]Indicates whether mute or not.
                                                                     [cn]是否静音*/
    TSDK_INT32 mic_index;                                       /**< [en]Indicates reserved.
                                                                     [cn]预留 */

}TSDK_S_MIC_BUTTON_STATE_INFO;


/**
 * [en]This structure is used to describe speaker button status information.
 * [cn]扬声器按钮状态信息
 */
typedef struct tagTSDK_S_SPEAKER_BUTTON_STATE_INFO
{
    TSDK_BOOL is_mute;                                          /**< [en]Indicates whether mute or not.
                                                                     [cn]是否静音*/
    TSDK_INT32 speaker_index;                                   /**< [en]Indicates reserved.
                                                                     [cn]预留 */

}TSDK_S_SPEAKER_BUTTON_STATE_INFO;


/**
 * [en]This structure is used to describe camera button status information.
 * [cn]摄像头按钮状态信息
 */
typedef struct tagTSDK_S_CAMERA_BUTTON_STATE_INFO
{
    TSDK_BOOL is_mute;                                          /**< [en]Indicates whether mute or not.
                                                                     [cn]是否关闭*/
    TSDK_INT32 camera_index;                                    /**< [en]Indicates reserved.
                                                                     [cn]预留 */

}TSDK_S_CAMERA_BUTTON_STATE_INFO;


/**
 * [en]This structure is used to describe layout information.
 * [cn]布局信息
 */
typedef struct tagTSDK_S_FRAME_LAYOUT_INFO
{
    TSDK_E_LAYOUT_TYPE layout;                                  /**< [en]Indicates UI layout type.
                                                                     [cn]UI布局类型*/
}TSDK_S_FRAME_LAYOUT_INFO;


/**
 * [en]This structure is used to describe page switching information.
 * [cn]页面切换信息
 */
typedef struct tagTSDK_S_PAGE_SWITCH_INFO
{
    TSDK_INT32 count;                                           /**< [en]Indicates total pages.
                                                                     [cn]总页数*/
    TSDK_INT32 pos;                                             /**< [en]Indicates index of the current page.
                                                                     [cn]当前页面索引*/
}TSDK_S_PAGE_SWITCH_INFO;


/**
 * [en]This structure is used to describe watch window information.
 * [cn]选看窗口信息
 */
typedef struct tagTSDK_S_UI_WATCH_ATTENDEE
{
    TSDK_UPTR hwnd;                                             /**< [en]Indicates specify the window handle of the selected operation object.
                                                                     [cn]指定选看操作对象的窗口句柄 */
}TSDK_S_UI_WATCH_ATTENDEE;


/**
 * [en]This structure is used to describe apply for or release the chairman.
 * [cn]申请或释放主席
 */
typedef struct tagTSDK_S_UI_CHAIRMAN_OPERATION
{
    TSDK_BOOL is_apply;                                         /**< [en]Indicates whether to apply for chairman.
                                                                     [cn]是否申请为主席 */
    TSDK_CHAR pwd[TSDK_D_MAX_PASSWORD_LENGTH + 1];              /**< [en]Indicates chairman password.
                                                                     [cn]主席密码 */
}TSDK_S_UI_CHAIRMAN_OPERATION;


/**
 * [en]This structure is used to describe move frame infomation.
 * [cn]移动frame信息
 */
typedef struct tagTSDK_S_UI_MOVE_FRAME_INFO
{
    TSDK_BOOL is_frame_moving;                                  /**< [en]Indicates whether to move frame or not.
                                                                     [cn]是否移动frame */
    TSDK_BOOL enable_move;                                      /**< [en]Indicates whether to enable move.
                                                                     [cn]是否启用移动 */
    TSDK_S_COORDINATES_AND_SIZE_INFO coordinate;                /**< [en]Indicates coordinates and size information.
                                                                     [cn]坐标及大小信息 */
}TSDK_S_UI_MOVE_FRAME_INFO;


/**
 * [en]This structure is used to describe focus plugin window.
 * [cn]聚焦插件窗口
 */
typedef struct tagTSDK_S_UI_PLUGIN_WND_FOCUS_INFO
{
    TSDK_BOOL is_native_wnd_focus;                              /**< [en]Indicates whether to focus window.
                                                                     [cn]是否聚焦窗口 */
    TSDK_INT32 left_top_x;                                      /**< [en]Indicates the left_top_x coordinate.
                                                                     [cn]左上角x坐标 */
    TSDK_INT32 left_top_y;                                      /**< [en]Indicates the left_top_y coordinate.
                                                                     [cn]左上角y坐标 */
}TSDK_S_UI_PLUGIN_WND_FOCUS_INFO;


/**
 * [en]This structure is used to describe plugin window size information .
 * [cn]插件窗口大小信息
 */
typedef struct tagTSDK_S_UI_PLUGIN_WND_SIZE_INFO
{
    TSDK_E_UI_WINDOW_SIZE native_wnd_size;                      /**< [en]Indicates UI window size.
                                                                     [cn]UI窗口大小 */
    TSDK_INT32 left_top_x;                                      /**< [en]Indicates the left_top_x coordinate.
                                                                     [cn]左上角x坐标 */
    TSDK_INT32 left_top_y;                                      /**< [en]Indicates the left_top_y coordinate.
                                                                     [cn]左上角y坐标 */
    TSDK_INT32 width;                                           /**< [en]Indicates the width.
                                                                     [cn]宽 */
    TSDK_INT32 height;                                          /**< [en]Indicates the height.
                                                                     [cn]高 */
    TSDK_BOOL move_enable;                                      /**< [en]Indicates whether to enable move.
                                                                     [cn]是否启用移动 */
}TSDK_S_UI_PLUGIN_WND_SIZE_INFO;


/**
 * [en]This structure is used to describe QOS information.
 * [cn]QOS信息
 */
typedef struct tagTSDK_S_UI_SHOW_QOS_INFO
{
    TSDK_BOOL is_show;                                          /**< [en]Indicates whether to display QOS information.
                                                                     [cn]是否显示QOS信息 */
}TSDK_S_UI_SHOW_QOS_INFO;


/**
 * [en]This structure is used to describe query user information.
 * [cn]查询用户信息
 */
typedef struct tagTSDK_S_UI_QUERY_USER_INFO
{
    TSDK_UPTR hwnd;                                             /**< [en]Indicates window handle of the object to be queried.
                                                                     [cn]待查询对象的窗口句柄 */
}TSDK_S_UI_QUERY_USER_INFO;


/**
 * [en]This structure is used to describe video control.
 * [cn]视频控制
 */
typedef struct tagTSDK_S_UI_CONF_CTRL_OPERATION
{
    TSDK_E_CONF_OPERATION_TYPE operation_type;                  /**< [en]Indicates operation type.
                                                                     [cn]会控操作类型 */

    TSDK_BOOL is_self;                                          /**< [en]Indicates specify whether the conference control operation object is itself. 
                                                                     [en]This parameter is valid only when operation_type is set to any of the following values:
                                                                     [en]TSDK_E_CONF_MUTE_ATTENDEE,
                                                                     [en]TSDK_E_CONF_UNMUTE_ATTENDEE.
                                                                     [cn]指定会控操作对象是否为自己，operation_type为
                                                                     [cn]TSDK_E_CONF_MUTE_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_UNMUTE_ATTENDEE,
                                                                     [cn]时有效   */

    TSDK_INT32 postpone_time;                                   /**< [en]Indicates conference extension time. Unit: Minute. This parameter is valid only when operation_type is set to TSDK_E_CONF_POSTPONE_CONF.
                                                                     [cn]会议延长时间，单位：分钟，operation_type为 TSDK_E_CONF_POSTPONE_CONF 时有效   */

    TSDK_UPTR hwnd;                                             /**< [en]Indicates specify the window handle of the conference control operation object. 
                                                                     [en]This parameter is valid only when operation_type is set to any of the following values:
                                                                     [en]TSDK_E_CONF_REMOVE_ATTENDEE,
                                                                     [en]TSDK_E_CONF_BROADCAST_ATTENDEE,
                                                                     [en]TSDK_E_CONF_SET_PRESENTER,
                                                                     [en]TSDK_E_CONF_HANG_UP_ATTENDEE,
                                                                     [en]TSDK_E_CONF_MUTE_ATTENDEE,
                                                                     [en]TSDK_E_CONF_UNMUTE_ATTENDEE,
                                                                     [en]TSDK_E_CONF_REDIAL_ATTENDEE.
                                                                     [cn]指定会控操作对象的窗口句柄，operation_type为
                                                                     [cn]TSDK_E_CONF_REMOVE_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_BROADCAST_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_SET_PRESENTER,
                                                                     [cn]TSDK_E_CONF_HANG_UP_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_MUTE_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_UNMUTE_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_REDIAL_ATTENDEE,
                                                                     [cn]时有效   */

    TSDK_CHAR user_num[TSDK_D_MAX_NUMBER_LEN + 1];              /**< [en]Indicates specify the number of the conference control operation object.
                                                                     [en]This parameter is valid only when operation_type is set to any of the following values:
                                                                     [en]TSDK_E_CONF_ADD_ATTENDEE,
                                                                     [en]TSDK_E_CONF_REDIAL_ATTENDEE.
                                                                     [cn]指定会控操作对象的号码，operation_type为
                                                                     [cn]TSDK_E_CONF_ADD_ATTENDEE,
                                                                     [cn]TSDK_E_CONF_REDIAL_ATTENDEE,
                                                                     [cn]时有效   */
}TSDK_S_UI_CONF_CTRL_OPERATION;


/**
 * [en]This structure is used to describe CPU usage.
 * [cn]cpu使用率
 */
typedef struct tagTSDK_S_UI_CPU_RATE
{
    TSDK_UINT32 cpu_rate;                           /**< [en]Indicates CPU usage.
                                                         [cn]cpu使用率 */
    TSDK_UINT32 duration_s;                         /**< [en]Indicates statistical interval time.
                                                         [cn]统计间隔时间 */
}TSDK_S_UI_CPU_RATE;


/**
 * [en]This structure is used to describe proactive switch between unidirectional and bidirectional.
 * [cn]主动切换单双向
 */
typedef struct tagTSDK_S_UI_ACTIVE_BIDIRECTION
{
    TSDK_INT32 conf_handle;                         /**< [en]Indicates conference handle.
                                                         [cn]会议句柄 */
    TSDK_INT32 dir;                                 /**< [en]Indicates the direction of the active switchover.
                                                         [cn]主动切换的方向 */
}TSDK_S_UI_ACTIVE_BIDIRECTION;


/**
 * [en]This structure is used to describe conference recording.
 * [cn]会议录制
 */
typedef struct tagTSDK_S_UI_NOTIFY_CONF_RECORDING
{
    TSDK_BOOL is_recording;                         /**< [en]Indicates whether is recording.
                                                         [cn]是否正在录制 */
}TSDK_S_UI_NOTIFY_CONF_RECORDING;


/**
 * [en]This structure is used to describe painting attribute.
 * [cn]绘画属性
 */
typedef struct tagTSDK_S_UI_PAINT_PROP
{
    TSDK_INT32 render_type;                         /**< [en]Indicates render type.
                                                         [cn]渲染类型 */
    TSDK_INT32 x_offset;                            /**< [en]Indicates x-axis offset.
                                                         [cn]x轴偏移量 */
    TSDK_INT32 y_offset;                            /**< [en]Indicates y-axis offset.
                                                         [cn]y轴偏移量 */
}TSDK_S_UI_PAINT_PROP;


/**
 * [en]This structure is used to describe shared quality.
 * [cn]共享质量
 */
typedef struct tagTSDK_S_UI_SHARE_QUALITY
{
    TSDK_INT32 quality_value;                       /**< [en]Indicates shared picture quality strategy.
                                                         [cn]共享画面质量策略 */
}TSDK_S_UI_SHARE_QUALITY;


/**
 * [en]This structure is used to describe display window.
 * [cn]显示窗口
 */
typedef struct tagTSDK_S_UI_SHOW_WINDOW
{
    TSDK_BOOL is_show;                              /**< [en]Indicates whether to display window.
                                                         [cn]是否显示窗口 */
}TSDK_S_UI_SHOW_WINDOW;


/**
 * [en]This structure is used to describe render size.
 * [cn]渲染尺寸
 */
typedef struct tagTSDK_S_UI_RENDER_SIZE
{
    TSDK_INT32 width;                               /**< [en]Indicates the width.
                                                         [cn]宽 */
    TSDK_INT32 height;                              /**< [en]Indicates the height.
                                                         [cn]高 */
}TSDK_S_UI_RENDER_SIZE;


/**
 * [en]This structure is used to describe window title.
 * [cn]窗口标题
 */
typedef struct tagTSDK_S_UI_WND_TITLE
{
    TSDK_CHAR title[TSDK_D_MAX_WND_TITLE_LEN + 1];  /**< [en]Indicates title.
                                                         [cn]标题 */
    TSDK_CHAR conf_id[TSDK_D_MAX_CONF_ID_LEN + 1];  /**< [en]Indicates conference ID.
                                                         [cn]会议ID */
}TSDK_S_UI_WND_TITLE;

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __TSDK_UI_PLUGIN_DEF_H__ */

