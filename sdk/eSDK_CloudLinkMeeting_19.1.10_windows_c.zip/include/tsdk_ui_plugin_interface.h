﻿
#ifndef __TSDK_UI_PLUGIN_INTERFACE_H__
#define __TSDK_UI_PLUGIN_INTERFACE_H__


#include "tsdk_ui_plugin_def.h"


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to set the UI button status (enabled or disabled).
 *        [cn] 设置UI按钮的状态(开启或关闭)
 *
 * @param [in] TSDK_E_UI_BUTTON_TYPE button      [en] Indicates UI button type (only the definition of the button type that needs to be set externally) is provided.
 *                                               [cn] UI按钮类型(仅提供需要外部设置状态的按钮类型定义)
 * @param [in] TSDK_BOOL is_off                  [en] Indicates whether to close or not.
 *                                               [cn] 是否关闭
 * @retval TSDK_RESULT                           [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                               [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see tsdk_set_user_info
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_set_button_state(TSDK_E_UI_BUTTON_TYPE button, TSDK_BOOL is_off);


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to display Local Window.
 *        [cn] 显示本地窗口
 *
 * @retval TSDK_RESULT                           [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                               [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_show_small_window(TSDK_VOID);


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to display annotations toolbar.
 *        [cn] 显示标注的工具栏
 *
 * @retval TSDK_RESULT                           [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                               [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_show_annotation_tool(TSDK_VOID);


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to set the window title.
 *        [cn] 设置窗口的标题
 *
 * @param [in] TSDK_S_UI_WND_TITLE *window_title [en] Indicates window title.
 *                                               [cn] 窗口标题
 * @retval TSDK_RESULT                           [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                               [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_set_window_title(TSDK_S_UI_WND_TITLE *window_title);


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to set the window size and relative position.
 *        [cn] 设置窗口的大小和相对位置
 *
 * @param [in] TSDK_S_UI_PLUGIN_WND_SIZE_PARAM* wnd_size_param [en] Indicates UI plugin window size and relative position parameters.
 *                                                             [cn] UI插件窗口大小和相对位置参数
 * @retval TSDK_RESULT                                         [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                                             [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_set_window_size_relative_pos(TSDK_S_UI_PLUGIN_WND_SIZE_PARAM* wnd_size_param);

/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to set the window size and absolute position.
 *        [cn] 设置窗口的大小和绝对位置
 *
 * @param [in] TSDK_S_UI_PLUGIN_WND_SIZE_PARAM* wnd_size_param [en] Indicates UI plugin window size and absolute position parameters.
 *                                                             [cn] UI插件窗口大小和绝对位置参数
 * @retval TSDK_RESULT                                         [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                                             [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_set_window_size_absolute_pos(TSDK_S_UI_PLUGIN_WND_SIZE_PARAM* wnd_size_param);


/**
 * @ingroup Ui Plugin
 * @brief [en] This interface is used to display video window in screen sharing.
 *        [cn] 主动共享时显示视频窗口
 *
 * @retval TSDK_RESULT                           [en] If it's success return TSDK_SUCCESS, otherwise return the corresponding error code.
 *                                               [cn] 成功返回TSDK_SUCCESS，失败返回相应错误码
 *
 * @attention NA
 * @see NA
 **/
TSDK_API TSDK_RESULT tsdk_ui_plugin_show_video_window(TSDK_VOID);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __TSDK_UI_PLUGIN_INTERFACE_H__ */


