module.exports = {
    "HISTORY": "Historique"
}