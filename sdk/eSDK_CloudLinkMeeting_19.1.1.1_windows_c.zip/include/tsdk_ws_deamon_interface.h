


#ifndef __TSDK_WS_DEAMON_INTERFACE_H__
#define __TSDK_WS_DEAMON_INTERFACE_H__

#include "tsdk_ws_deamon_def.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


TSDK_API TSDK_RESULT tsdk_startup_ws_service_deamon(TSDK_S_WEB_SOCKET_SERVICE_DEAMON_PARAM *service_deamon_param);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __TSDK_WS_DEAMON_INTERFACE_H__ */

